The files in this github repository consists of all the deliverables for Homework 1 of this course. 
Part 1:
React app on netlify : https://fse-tuiter.netlify.app/
React app on github : https://github.com/bhoomikamadhukar/FSE-React
Heroku link : https://fse-node-tuiter.herokuapp.com/
Github link for node : https://github.com/bhoomikamadhukar/Fse-Node

Part 2:
Both the UML diagram and the PDF for the use cases are in UML folder. 

Part 3: 
All the code is in the respective folders created as per instructions. 
The data dump can be found in data folder.