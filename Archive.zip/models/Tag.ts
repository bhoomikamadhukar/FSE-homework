/**
 * @typedef Tag Represents Tag of tuits
 * @property {string} tag The tag of the tuit
*/
export default class Tag {
    private tag: string = '';
}
