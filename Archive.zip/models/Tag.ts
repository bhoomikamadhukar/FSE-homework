export default class Tag {
    private tag: string = '';
}
