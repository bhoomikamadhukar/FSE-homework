/**
 * @typedef Topic Represents Topics of tuits
 * @property {string} topic The topic of the tuit
*/
export default class Topic {
    private topic: string = '';
}
